<?php
namespace Elektronik\RiceCooker\Maspion;
class Produk { 
  public $merek = "Maspion";
}
