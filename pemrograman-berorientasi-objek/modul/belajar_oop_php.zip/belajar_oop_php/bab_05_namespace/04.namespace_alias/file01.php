<?php
include("file02.php");
include("file03.php");

use KipasAngin\Miyako\Produk as MiyakoProduk;
use Elektronik\RiceCooker\Maspion\Produk as MaspionProduk;

$produk01 = new MiyakoProduk();
echo $produk01->merek;

echo "<br>";

$produk02 = new MaspionProduk();
echo $produk02->merek;