<?php
class Produk { 
  public $merek = "Miyako";
}
