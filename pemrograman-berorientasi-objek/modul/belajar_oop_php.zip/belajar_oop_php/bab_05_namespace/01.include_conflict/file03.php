<?php
class Produk { 
  public $merek = "Maspion";
}
