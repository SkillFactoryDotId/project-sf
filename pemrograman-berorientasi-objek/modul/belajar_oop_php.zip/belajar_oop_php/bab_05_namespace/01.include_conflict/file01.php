<?php
include("file02.php");
//include("file03.php");

$produk01 = new Produk();
echo $produk01->merek;
