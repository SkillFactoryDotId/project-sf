<?php
include("file02.php");

$produk01 = new Miyako\Produk();
echo $produk01->merek;
echo "<br>";
echo Miyako\hidupkan();
echo "<br>";
echo Miyako\JENIS;
echo "<br>";
echo $harga;
