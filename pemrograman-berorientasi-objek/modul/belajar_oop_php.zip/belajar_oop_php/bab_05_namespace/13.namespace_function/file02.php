<?php
namespace Miyako;

class Produk {
  public $merek = "Miyako";
}

function hidupkan(){ 
  return "Wuzz...";
}

const JENIS = "Kipas Angin";
$harga = 150000;