<?php
namespace Elektronik\Miyako {
  class Produk {
    public $merek = "Miyako";
  }
  
  $produk01 = new Produk();
  echo $produk01->merek;       // Miyako
  
  echo "<br>";
}

namespace Elektronik\Maspion {
  class Produk {
    public $merek = "Maspion";
  }
  
  $produk02 = new Produk();
  echo $produk02->merek;       // Maspion
}