<?php
//declare(strict_types=1);
//echo "Test";
namespace Miyako;

class Produk {
  public $merek = "Miyako";
}
