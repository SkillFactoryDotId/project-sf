<?php
namespace Maspion;

class Produk {
  public $merek = "Maspion";
}
