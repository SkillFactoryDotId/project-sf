<?php

// Cara 1

// include("file02.php");
// include("file03.php");
//
// $produk01 = new Elektronik\Komputer\Laptop("Lenovo");
// echo $produk01->getInfo();
//
// echo "<br>";
//
// $produk02 = new Elektronik\Televisi("Sony",5000000);
// echo $produk02->getInfo();

//===============================================================


// Cara 2

// include("file02.php");
// include("file03.php");
//
// use Elektronik\Komputer\Laptop;
// use Elektronik\Televisi;
//
// $produk01 = new Laptop("Lenovo");
// echo $produk01->getInfo();
//
// echo "<br>";
//
// $produk02 = new Televisi("Sony",5000000);
// echo $produk02->getInfo();

//===============================================================


// Cara 3

namespace Elektronik\Komputer{
  include("file02.php");

  $produk01 = new Laptop("Lenovo");
  echo $produk01->getInfo();

  echo "<br>";
}

namespace Elektronik{
  include("file03.php");

  $produk02 = new Televisi("Sony",5000000);
  echo $produk02->getInfo();
}
