<?php
namespace Miyako;

//include("file03.php");

include("C:/xampp/htdocs/belajar_oop_php/bab_05/09.namespace_global_relative_2/file03.php");


class Produk {
  public $merek = "Miyako";
}

$produk01 = new \Produk();
echo $produk01->merek;
