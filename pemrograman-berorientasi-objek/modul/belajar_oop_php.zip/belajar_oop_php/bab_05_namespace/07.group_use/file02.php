<?php
namespace Produk\KipasAngin;

class MiyakoProduk {
  public $merek = "Miyako";
}
