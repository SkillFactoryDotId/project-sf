<?php
namespace Produk\KipasAngin;

class MaspionProduk {
  public $merek = "Maspion";
}
