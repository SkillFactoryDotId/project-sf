<?php
include("file02.php");
include("file03.php");

//use Produk\KipasAngin\MiyakoProduk;
//use Produk\KipasAngin\MaspionProduk;

use Produk\KipasAngin\{MaspionProduk,MiyakoProduk};

$produk01 = new MiyakoProduk();
echo $produk01->merek;

echo "<br>";

$produk02 = new MaspionProduk();
echo $produk02->merek;
