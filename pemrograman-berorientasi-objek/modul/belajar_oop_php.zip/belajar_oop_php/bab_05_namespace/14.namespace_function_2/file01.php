<?php
namespace Elektronik;

$waktu = new \DateTime();
echo $waktu->format('d-m-Y H:i:s');

echo "<br>";

echo \date('d-m-Y H:i:s');
