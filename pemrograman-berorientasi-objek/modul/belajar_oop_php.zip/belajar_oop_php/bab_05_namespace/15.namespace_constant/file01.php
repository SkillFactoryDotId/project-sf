<?php
namespace Elektronik;
echo __NAMESPACE__;
echo "<br>";

namespace Produk\Elektronik\KipasAngin;
echo __NAMESPACE__;