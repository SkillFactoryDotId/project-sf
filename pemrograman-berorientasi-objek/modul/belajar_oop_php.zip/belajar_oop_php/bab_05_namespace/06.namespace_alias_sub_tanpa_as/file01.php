<?php
include("file03.php");

use Elektronik\RiceCooker\Maspion\Produk;

$produk02 = new Produk();
echo $produk02->merek;
