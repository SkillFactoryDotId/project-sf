<?php
include("file02.php");
include("file03.php");

$produk01 = new KipasAngin\Miyako\Produk();
echo $produk01->merek;

echo "<br>";

$produk01 = new Elektronik\RiceCooker\Maspion\Produk();
echo $produk01->merek;
