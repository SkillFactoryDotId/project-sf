<?php
namespace KipasAngin\Miyako;

class Produk {
  public $merek = "Miyako";
}
