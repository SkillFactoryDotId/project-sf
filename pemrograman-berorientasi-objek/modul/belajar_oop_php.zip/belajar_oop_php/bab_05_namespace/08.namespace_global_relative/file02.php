<?php
namespace Miyako;

class Produk {
  public $merek = "Miyako";
}

$produk01 = new Produk();
echo $produk01->merek;   // Miyako

$produk02 = new stdClass();
