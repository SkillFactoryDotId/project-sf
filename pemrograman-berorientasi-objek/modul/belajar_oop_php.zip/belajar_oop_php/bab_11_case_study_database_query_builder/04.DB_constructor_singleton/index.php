<?php
require 'DB.php';
// $DB = new DB();

// $DB = DB::getInstance();

$DB = DB::getInstance();
$DB = DB::getInstance();
$DB = DB::getInstance();

// echo "<pre>";
// var_dump($DB);
// echo "</pre>";
