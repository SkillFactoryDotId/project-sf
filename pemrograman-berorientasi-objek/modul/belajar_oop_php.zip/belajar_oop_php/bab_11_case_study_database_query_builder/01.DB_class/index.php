<?php
require 'DB.php';
$DB = new DB();

echo "<pre>";
var_dump($DB);
echo "</pre>";
