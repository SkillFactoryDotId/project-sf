<?php
require 'DB.php';
$DB = new DB();
$DB = new DB();
$DB = new DB();