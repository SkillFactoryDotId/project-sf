<?php
function foo($a){
  if ($a === 0){
    throw new Exception("Argument \$a tidak bisa diisi angka 0");
  }
  else {
    return 1/$a;
  }
}

try {
  echo foo(0);
}
catch (Exception $e) {
  echo "Terjadi error dalam file <b>".$e->getTrace()[0]["file"]."</b>,
       di baris ke-".$e->getTrace()[0]["line"]." dengan keterangan <b>".
       $e->getMessage()."</b>.";
}
