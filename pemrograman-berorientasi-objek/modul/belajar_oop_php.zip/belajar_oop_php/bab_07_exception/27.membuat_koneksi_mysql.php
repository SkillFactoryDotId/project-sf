<?php
// Set agar error menggunakan exception
mysqli_report(MYSQLI_REPORT_STRICT);

// Tes buat koneksi dengan MySQL Server
try {
  $mysqli = new mysqli('localhost','root','','coba');
}
catch (mysqli_sql_exception $e) {
  echo "Hasil pesan exception adalah: ".$e->getMessage();
}
