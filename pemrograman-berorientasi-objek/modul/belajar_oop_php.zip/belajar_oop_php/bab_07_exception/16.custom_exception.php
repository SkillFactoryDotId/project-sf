<?php
class NolException extends Exception{}
class NegatifException extends Exception{}

function foo($a){
  if ($a === 0){
    throw new NolException();
  }
  else if ($a < 0){
    throw new NegatifException();
  }
  else {
    return 1/$a;
  }
}

try {
  echo foo(0);
}
catch (NolException $e) {
  echo "Argument tidak bisa diisi angka 0 <br>";
}
catch (NegatifException $e) {
  echo "Argument tidak bisa diisi angka negatif <br>";
}

try {
  echo foo(-20);
}
catch (NolException $e) {
  echo "Argument tidak bisa diisi angka 0 <br>";
}
catch (NegatifException $e) {
  echo "Argument tidak bisa diisi angka negatif <br>";
}
