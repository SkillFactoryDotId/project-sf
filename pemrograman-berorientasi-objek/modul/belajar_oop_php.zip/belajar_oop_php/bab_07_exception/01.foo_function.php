<?php
function foo($a){
  return 1/$a;
}

echo foo(2);      echo "<br>";
echo foo(100);    echo "<br>";
echo foo(0);      echo "<br>";
echo foo(-20);    echo "<br>";
