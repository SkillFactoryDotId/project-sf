<?php
function foo($a){
  if ($a === 0){
    throw new Exception('Argument tidak bisa diisi angka 0');
  }
  else {
    return 1/$a;
  }
}

function bar($b){
  return foo($b);
}

try {
  echo bar(0);
}
catch (Exception $e) {
  echo "Terjadi error di baris ke-".$e->getTrace()[0]["line"].
  " dengan keterangan <b>".$e->getMessage()."</b><br>";
}
