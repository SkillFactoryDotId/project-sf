<?php
function foo($a){
  if ($a === 0){
    throw new Exception("Argument \$a tidak bisa diisi angka 0",99);
  }
  else {
    return 1/$a;
  }
}

try {
  echo foo(0);
}
catch (Exception $e) {
  echo $e->getMessage()       ."<br>";
  echo $e->getCode()          ."<br>";
  echo $e->getFile()          ."<br>";
  echo $e->getLine()          ."<br>";
  echo $e->getTraceAsString() ."<br>";

  echo "<pre>";
  print_r( $e->getTrace() );
  echo "</pre>";
}
