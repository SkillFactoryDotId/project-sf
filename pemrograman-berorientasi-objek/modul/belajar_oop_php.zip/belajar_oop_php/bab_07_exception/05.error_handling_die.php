<?php
function foo($a){
  if ($a === 0){
    die("Argument \$a tidak bisa diisi angka 0");
  }
  else if ($a < 0){
    die("Argument \$a tidak bisa diisi angka negatif");
  }
  else {
    return 1/$a;
  }
}

echo foo(2);      echo "<br>";
echo foo(100);    echo "<br>";
echo foo(0);      echo "<br>";
echo foo(-20);    echo "<br>";