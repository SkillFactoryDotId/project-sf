<?php
function foo($a){
  if ($a === 0){
    throw new Exception('Argument tidak bisa diisi angka 0');
  }
  else if ($a < 0){
    throw new Exception("Argument \$a tidak bisa diisi angka negatif");
  }
  else {
    return 1/$a;
  }
}

function bar($b){
  return foo($b);
}

function baz($b){
  return bar($b);
}

try {
  echo baz(-10);
}
catch (Exception $e) {
  echo "Error: <b>".$e->getMessage()."</b><br>";

  echo "<br>Trace error: <br>";

  foreach ($e->getTrace() as $value) {
    echo "Baris ke-".$value ["line"];
    echo ", error di function ".$value ["function"];
    echo ", dengan argument ".$value ["args"][0]."<br>";
  }
}
