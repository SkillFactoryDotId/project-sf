<?php
function foo($a){
  if ($a === 0){
    throw new Exception("Argument \$a tidak bisa diisi angka 0");
  }
  else {
    return 1/$a;
  }
}

try {
  echo foo(0);
}
catch (Exception $e) {
  echo $e;
}
