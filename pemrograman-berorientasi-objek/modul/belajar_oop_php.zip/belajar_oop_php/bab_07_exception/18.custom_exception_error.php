<?php

class NolException extends Exception{
  public function pesanKesalahan(){
    return "Argument tidak bisa diisi angka 0, di baris "
            .$this->getTrace()[0]["line"] ." <br>";
  } 
}

class NegatifException extends Exception{
  public function pesanKesalahan(){
    return "Argument tidak bisa diisi angka negatif, di baris "
           .$this->getTrace()[0]["line"] ." <br>";
  }
}

function foo($a){
  if ($a === 0){
    throw new NolException();
  }
  else if ($a < 0){
    throw new NegatifException();
  }
  else if (!is_numeric($a)){
    throw new Exception('Argument yang diinput bukan angka');
  }
  else {
    return 1/$a;
  }
}

try {
  echo foo('a'); 
}
catch (NolException $e) {
  echo $e->pesanKesalahan();
}
catch (NegatifException $e) {
  echo $e->pesanKesalahan();
}
