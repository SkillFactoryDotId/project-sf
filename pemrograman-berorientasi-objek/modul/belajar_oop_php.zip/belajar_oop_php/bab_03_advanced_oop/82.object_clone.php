<?php
class Laptop {
  private $merek;

  public function __construct($merek){
    $this->merek = $merek;
  }

  public function cekMerek(){
    return $this->merek;
  }

  public function setMerek($merek){
    $this->merek = $merek;
  }
}

$produk01 = new Laptop('Asus');
$produk02 = clone $produk01;

echo $produk01->cekMerek()."<br>";     // Asus
echo $produk02->cekMerek()."<br>";     // Asus

$produk02->setMerek('Dell')."<br>";

echo $produk01->cekMerek()."<br>";     // Asus
echo $produk02->cekMerek()."<br>";     // Dell
