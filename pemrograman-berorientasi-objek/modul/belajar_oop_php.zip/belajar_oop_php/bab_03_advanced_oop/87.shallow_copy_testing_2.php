<?php
class Perusahaan {
  public $nama;

  public function __construct($nama){
    $this->nama = $nama;
  }
}

class Laptop {
  public $merek;
  public $suplier;

  public function __construct($merek){
    $this->merek = $merek;
  }
}

$suplierLaptop = new Perusahaan("CV. Jaya Abadi");
$produk01 = new Laptop("Acer");
$produk01->suplier = $suplierLaptop;

$produk02 = clone $produk01;

$produk02->merek = "Apple";
$produk02->suplier->nama = "CV. Maju Makmur";

echo "<pre>";
print_r($produk01);
echo "</pre>";

echo "<pre>";
print_r($produk02);
echo "</pre>";