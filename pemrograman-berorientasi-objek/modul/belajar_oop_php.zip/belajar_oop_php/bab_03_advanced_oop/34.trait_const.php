<?php
trait SmartElectronic{
  public $internet = "Telkom Indihome";
  const KECEPATAN = "10 Mbps";
  public function cekOS(){
    return "Android 9.0 (Pie)";
  }
}

echo SmartElectronic::KECEPATAN;   //  Fatal error: Traits cannot have constants
