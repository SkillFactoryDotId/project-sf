<?php
interface ProdukEkspor {
  public function cekHargaUsd();
  public function cekNegara();
}

class ProdukEkspor{
}

// Fatal error: Cannot declare class ProdukEkspor, because the name is already in use