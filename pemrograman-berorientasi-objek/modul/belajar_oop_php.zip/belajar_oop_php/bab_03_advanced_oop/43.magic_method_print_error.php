<?php
class Produk {
}

$produk01 = new Produk();
echo $produk01; // Recoverable fatal error: Object of class Produk could not be converted to string
