<?php
class Produk {
  public function __call($name,$arguments){
    echo "Maaf method $name dengan argument ". implode(", ",$arguments);
    echo " tidak tersedia <br>";
  }
}

$produk01 = new Produk();
$produk01->tambah(3, 7, 8);  
$produk01->setMerek("Xiaomi","Vivo","Oppo"); 
