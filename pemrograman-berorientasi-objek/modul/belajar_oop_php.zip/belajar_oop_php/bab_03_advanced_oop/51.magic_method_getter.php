<?php
class Produk {
  private $merek = "Logitech";
  private $harga = 150000;
  private $tipe = "Mouse";

  public function __get($name) {
    if ($name == "merek"){
      $hasil = strtoupper($this->merek);
    }
    else if ($name == "harga"){
      $hasil = "Rp. ".number_format($this->harga,2,",",".");
    }
    else if ($name == "tipe"){
      $hasil = "Tipe produk: ".$this->tipe;
    }
    else {
      $hasil = "Maaf property '$name' tidak terdefinisi";
    }
    return $hasil;
  }
}

$produk01 = new Produk();
echo $produk01->merek;    // LOGITECH
echo "<br>";
echo $produk01->harga;    // Rp. 150.000,00
echo "<br>";
echo $produk01->tipe;     // Tipe produk: Mouse
echo "<br>";
echo $produk01->warna;    // Maaf property 'warna' tidak terdefinisi
