<?php
declare(strict_types=1);

class Smartphone {
  public int $jumlah;
}

$produk01 = new Smartphone();
$produk01->jumlah = "100";

var_dump($produk01->jumlah);  
 // Fatal error: Uncaught TypeError: Cannot assign string to property 
 // Smartphone::$jumlah of type int