<?php
class Produk {
  public $merek = "Logitech";
  
  public function __get($name) {
    return "Maaf property '$name' tidak terdefinisi";
  }
}

$produk01 = new Produk();
echo $produk01->merek;  // Logitech
echo "<br>";
echo $produk01->harga;  // Maaf property 'harga' tidak terdefinisi
