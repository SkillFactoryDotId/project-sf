<?php
class Produk {
  protected static $merek = "LG";

  public static function cekMerek(){
    return "Produk dengan merek ".self::$merek." tersedia";
  }

  public static function getInfo(){
    return self::cekMerek();
  }
}

class MesinCuci extends Produk {
  public static function cekMerek(){
    return "Mesin cuci dengan merek ".self::$merek." tersedia";
  }
}

echo Produk::getInfo();
echo "<br>";
echo MesinCuci::getInfo();