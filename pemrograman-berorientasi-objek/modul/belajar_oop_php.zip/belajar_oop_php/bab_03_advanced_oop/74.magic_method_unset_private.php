<?php
class Produk {
  private $merek = "Sony";

  public function __unset($name){
    echo "Maaf, property $name tidak ada / tidak bisa diakses";
  }
}

$produk01 = new Produk();
unset($produk01->merek);
