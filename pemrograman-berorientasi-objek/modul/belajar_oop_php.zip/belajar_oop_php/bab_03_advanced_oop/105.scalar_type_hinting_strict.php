<?php
declare(strict_types=1);

function tambah(int $a,int $b){
  return $a + $b;
}

echo tambah(5,6);        // 11
echo "<br>";
echo tambah(6.5,8.9);
echo "<br>";
echo tambah("5",6);
// Fatal error: Uncaught TypeError: Argument 1 passed to tambah() must be of the type integer, float given
