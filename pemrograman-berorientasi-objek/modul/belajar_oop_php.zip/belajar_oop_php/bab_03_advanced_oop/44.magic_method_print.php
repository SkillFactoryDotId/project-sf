<?php
class Produk {
  public function __toString(){
    return "Ini berasal dari class Produk";
  }
}

$produk01 = new Produk();
echo $produk01;  // Ini berasal dari class Produk
