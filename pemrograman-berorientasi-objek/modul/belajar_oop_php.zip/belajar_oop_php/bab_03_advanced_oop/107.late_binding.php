<?php
class Produk {
  protected $merek = "LG";

  public function cekMerek(){
    return "Produk dengan merek $this->merek tersedia";
  }

  public function getInfo(){
    return $this->cekMerek();
  }
}

class MesinCuci extends Produk {
  public function cekMerek(){
    return "Mesin cuci dengan merek $this->merek tersedia";
  }
}

$produk01 = new Produk;
echo $produk01->getInfo();

echo "<br>";

$produk02 = new MesinCuci;
echo $produk02->getInfo();
