<?php
trait HardCover {
  public function cekTrait(){
    $psn = "Pesan ini berasal dari method ".__METHOD__;
    $psn .= " di dalam trait ".__TRAIT__;
    return $psn;
  }
}

class Buku {
  use HardCover;
  public function cekClass(){
    $psn = "Pesan ini berasal dari method ".__METHOD__;
    $psn .= " di dalam class ".__CLASS__;
    return $psn;
  }
}

$produk01 = new Buku();
echo $produk01->cekTrait();
echo "<br>";
echo $produk01->cekClass();
