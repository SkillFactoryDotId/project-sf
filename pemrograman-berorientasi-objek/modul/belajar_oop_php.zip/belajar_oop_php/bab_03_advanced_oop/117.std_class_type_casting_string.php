<?php
$foo = "Belajar OOP PHP";
$bar = (object) $foo;

var_dump($bar);
