<?php
declare(strict_types=1);

class Smartphone {
  public string $merek;
}

$produk01 = new Smartphone();
$produk01->merek = 100;   // Fatal error: Uncaught TypeError: Cannot assign int 
                          // to property Smartphone::$merek of type string