<?php
interface ProdukEkspor {
  public function cekHargaUsd();
  public function cekNegara();
}

interface ProdukMakanan {
  public function cekExpired();
}

interface ProdukMakananBeku extends ProdukMakanan {
  public function cekSuhuMin();
}

class Nugget implements ProdukEkspor, ProdukMakananBeku {
  public function cekHargaUsd(){
    return 7.5;
  }
  public function cekNegara(){
    return ["Singapura", "Malaysia","Thailand"];
  }
  public function cekSuhuMin(){
    return -14;
  }
}