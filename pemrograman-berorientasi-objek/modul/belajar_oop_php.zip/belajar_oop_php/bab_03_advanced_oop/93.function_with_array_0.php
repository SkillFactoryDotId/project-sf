<?php

function hitungRata2($data){
  return ($data[0] + $data[1] + $data[2])/3;
}

echo hitungRata2(3, 6, 12);  // 0