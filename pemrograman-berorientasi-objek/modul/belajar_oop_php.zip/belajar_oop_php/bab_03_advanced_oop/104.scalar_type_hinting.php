<?php
function tambah(int $a,int $b){
  return $a + $b;
}

echo tambah(5,6);      // 11
echo "<br>";
echo tambah(6.5,8.9);  // 14
echo "<br>";
echo tambah("5",6);    // 11