<?php
class Produk {
  protected $merek = "Sony";
  protected $stok;
  protected $tipe = "";
}

$produk01 = new Produk();
var_dump(isset($produk01->merek));   // bool(false)
echo "<br>";
var_dump(isset($produk01->stok));    // bool(false)
echo "<br>";
var_dump(isset($produk01->tipe));    // bool(false)
echo "<br>";

var_dump(empty($produk01->merek));   // bool(true)
echo "<br>";
var_dump(empty($produk01->stok));    // bool(true)
echo "<br>";
var_dump(empty($produk01->tipe));    // bool(true)