<?php
function tambah($a, $b){
  return $a + $b;
}

echo tambah(5,6);      // 11
echo "<br>";
echo tambah(6.5,8.9);  // 15.4
echo "<br>";
echo tambah("5",6);    // 11
