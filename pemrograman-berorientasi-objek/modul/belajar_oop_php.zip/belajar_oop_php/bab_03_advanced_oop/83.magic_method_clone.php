<?php
class Laptop {
  private $merek;

  public function __construct($merek){
    $this->merek = $merek;
  }

  public function __clone(){
    echo "Object Laptop di cloning... <br>";
  }
}

$produk01 = new Laptop('Asus');
$produk02 = clone $produk01;
$produk03 = clone $produk02;