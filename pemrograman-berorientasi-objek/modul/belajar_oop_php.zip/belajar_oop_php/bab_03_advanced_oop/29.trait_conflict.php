<?php
trait SmartElectronic{
  public function efisiensi(){
    return "Konsumsi daya 1.1";
  }
}

trait LowWatt{
  public function efisiensi(){
    return "Konsumsi daya 0.8";
  }
}

class SmartTV{
  use SmartElectronic, LowWatt;
}

$produk01 = new SmartTV;
echo $produk01->efisiensi();

//  Fatal error: Trait method efisiensi has not been applied, because there are collisions with other trait methods on SmartTV