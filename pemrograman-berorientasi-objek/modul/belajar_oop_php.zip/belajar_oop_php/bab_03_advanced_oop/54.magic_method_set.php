<?php
class Produk {
  public function __set($name, $value) {
    echo "Maaf property '$name' tidak tersedia dan tidak bisa diisi '$value'";
  } 
}

$produk01 = new Produk();
$produk01->merek = "Logitech";
echo "<br>";
$produk01->harga = 15000;
echo "<br>";
$produk01->tipe = "Mouse";