<?php
declare(strict_types=1);

class Smartphone {
  public float|int $jumlah;
}

$produk01 = new Smartphone();

$produk01->jumlah = 100;
var_dump($produk01->jumlah); // int(100)

$produk01->jumlah = 40.5;
var_dump($produk01->jumlah); // float(40.5)

$produk01->jumlah = "100";  // // Fatal error: Uncaught TypeError
var_dump($produk01->jumlah); 