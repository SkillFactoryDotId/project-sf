<?php
class Televisi {
  public function efisiensi(){
    return "Konsumsi daya 1.0";
  }
}

trait LowWatt{
  public function efisiensi(){
    return "Konsumsi daya 0.8";
  }
}

class SmartTV extends Televisi{
  use LowWatt;

  public function efisiensi(){
    return "Konsumsi daya 0.9";
  }
}

$produk01 = new SmartTV;
echo $produk01->efisiensi();    //  Konsumsi daya 0.9
