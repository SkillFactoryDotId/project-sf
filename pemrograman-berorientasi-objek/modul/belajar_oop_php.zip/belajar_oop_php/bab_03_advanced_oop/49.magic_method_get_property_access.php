<?php
class Produk {
  private $merek = "Logitech";
  
  public function __get($name) {
    return "Maaf property '$name' tidak terdefinisi";
  }
}

$produk01 = new Produk();
echo $produk01->merek;  // Maaf property 'merek' tidak terdefinisi
echo "<br>";
echo $produk01->harga;  // Maaf property 'harga' tidak terdefinisi
