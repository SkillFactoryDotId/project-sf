<?php
class Smartphone {
  public $merek;
  public $tipe;
  public $harga;
 
  public function __construct($merek,$tipe,$harga){
    $this->merek = $merek;
    $this->tipe = $tipe;
    $this->harga = $harga;
  }
}

class Televisi {
  public $merek;
  public $tipe;
  public $harga;
 
  public function __construct($merek,$tipe,$harga){
    $this->merek = $merek;
    $this->tipe = $tipe;
    $this->harga = $harga;
  }
}

function tampilkanSmartphone(Smartphone $hp){
  return "Smartphone ".$hp->merek." ".$hp->tipe." di jual seharga Rp. "
       .number_format($hp->harga,2,",",".");
}

$produk01 = new Televisi("Samsung", "LED TV 40 inch UA40M5000",4499000);
$produk02 = new Smartphone("Samsung","Galaxy S9+",11999000);

echo tampilkanSmartphone($produk01);
// Fatal error: Uncaught TypeError: Argument 1 passed to tampilkanSmartphone() must be an instance of Smartphone, instance of Televisi given
echo "<br>";
echo tampilkanSmartphone($produk02);

