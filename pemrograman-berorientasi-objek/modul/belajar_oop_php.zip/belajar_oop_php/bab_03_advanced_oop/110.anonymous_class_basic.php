<?php
$produk01 = new class(){};

var_dump($produk01);  // object(class@anonymous)#1 (0) { } 