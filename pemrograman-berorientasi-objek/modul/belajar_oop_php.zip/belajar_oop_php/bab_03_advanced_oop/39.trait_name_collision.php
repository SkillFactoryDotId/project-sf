<?php
trait SmartElectronic{  }

class SmartElectronic{  }

// Fatal error: Cannot declare class SmartElectronic, because the name is already in use
