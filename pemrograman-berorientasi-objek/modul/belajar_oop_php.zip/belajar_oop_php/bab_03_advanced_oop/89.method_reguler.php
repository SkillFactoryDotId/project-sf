<?php

class Televisi {
  private $merek;
  private $jenisLayar;
  private $ukuranLayar;

  public function setMerek($merek){
    $this->merek = $merek;
  }
  public function setJenisLayar($jenisLayar){
    $this->jenisLayar = $jenisLayar;
  }
  public function setUkuranLayar($ukuranLayar){
    $this->ukuranLayar = $ukuranLayar;
  }

  public function cekInfo(){
    return "Televisi ".$this->jenisLayar." ".$this->merek." ".
           $this->ukuranLayar." inch";
  }

}

$produk01 = new Televisi();

$produk01->setMerek("Samsung");
$produk01->setJenisLayar("LED");
$produk01->setUkuranLayar("42");

echo $produk01->cekInfo();
