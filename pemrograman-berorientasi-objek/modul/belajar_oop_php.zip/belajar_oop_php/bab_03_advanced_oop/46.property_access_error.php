<?php
class Produk {
}

$produk01 = new Produk();
echo $produk01->merek;  // Notice: Undefined property: Produk::$merek