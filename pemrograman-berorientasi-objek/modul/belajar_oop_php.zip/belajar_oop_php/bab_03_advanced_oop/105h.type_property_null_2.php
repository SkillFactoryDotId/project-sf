<?php
class Smartphone {
  public ?Perusahaan $suplier;
}

$produk01 = new Smartphone();
$produk01->suplier = null;  

var_dump($produk01->suplier); // NULL
