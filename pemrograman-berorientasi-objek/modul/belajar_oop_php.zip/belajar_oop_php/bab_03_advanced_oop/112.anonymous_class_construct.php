<?php
$produk01 = new class("Sony"){
  private $merek;

  public function __construct($foo){
    $this->merek = $foo;
  }

  public function getMerek(){
    return $this->merek;
  }
};

echo $produk01->getMerek();  // Sony
