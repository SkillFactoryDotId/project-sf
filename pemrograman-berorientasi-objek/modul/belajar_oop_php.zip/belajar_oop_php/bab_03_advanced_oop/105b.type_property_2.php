<?php
class Smartphone {
  public string $merek;
}

$produk01 = new Smartphone();
$produk01->merek = 100;

var_dump($produk01->merek);  // string(3) "100"