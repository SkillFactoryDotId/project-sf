<?php
$a = 5;
$b = $a;

$a = 10;

echo $a;  // 10
echo $b;  // 5