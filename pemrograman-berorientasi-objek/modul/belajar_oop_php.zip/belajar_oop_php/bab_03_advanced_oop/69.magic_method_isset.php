<?php
class Produk {
  public $merek = "Sony";
  protected $stok = 9;
  private $tipe = "Televisi";

  public function __isset($name)  {
    echo "Apakah property '$name' ada? ";
    return isset($this->$name);
  }
}

$produk01 = new Produk();
var_dump(isset($produk01->merek));
echo "<br>";
var_dump(isset($produk01->stok));
echo "<br>";
var_dump(isset($produk01->tipe));
echo "<br>";
var_dump(isset($produk01->warna));
