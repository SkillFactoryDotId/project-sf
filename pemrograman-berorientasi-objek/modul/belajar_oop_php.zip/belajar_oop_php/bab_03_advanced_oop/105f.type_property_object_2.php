<?php
class Perusahaan { }

class Smartphone {
  public Perusahaan $suplier;
}

$suplier01 = new Perusahaan();
$produk01 = new Smartphone();
$produk01->suplier = $suplier01;  