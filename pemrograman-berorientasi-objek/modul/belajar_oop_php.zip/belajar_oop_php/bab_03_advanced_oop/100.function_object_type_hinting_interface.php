<?php
class Produk {
  public $merek;
  public $tipe;
  public $harga;

  public function __construct($merek,$tipe,$harga){
    $this->merek = $merek;
    $this->tipe = $tipe;
    $this->harga = $harga;
  }
}

interface SmartElectronic{
  public function cekOS();
}

class Televisi extends Produk implements SmartElectronic{
  public function cekOS(){
    return "Android 9.0 (Pie)";
  }
}

function tampilkanProduk(SmartElectronic $barang){
  return "Produk ".$barang->merek." ".$barang->tipe.", dengan "
         .$barang->cekOS()." di jual seharga Rp. "
         .number_format($barang->harga,2,",",".");
}

$produk01 = new Televisi("Samsung", "LED TV 40 inch UA40M5000",4499000);
echo tampilkanProduk($produk01);
