<?php
$produk01 = new stdClass;
$produk01->merek = "Oppo";
$produk01->tipe = "Find X";
$produk01->harga = 13499000;

echo $produk01->merek."<br>";
echo $produk01->tipe."<br>";
echo $produk01->harga."<br>";
echo "<br>";
var_dump($produk01);