<?php
interface ProdukEkspor {
  private function cekHargaUsd();
  protected function cekNegara();
}

// Fatal error: Access type for interface method ProdukEkspor::cekHargaUsd() must be omitted
