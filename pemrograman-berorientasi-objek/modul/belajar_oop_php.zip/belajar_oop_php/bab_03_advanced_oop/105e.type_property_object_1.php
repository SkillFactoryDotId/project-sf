<?php
class Smartphone {
  public Perusahaan $suplier;
}

$produk01 = new Smartphone();
$produk01->suplier = "PT. ABC";  
// Fatal error: Uncaught TypeError: Cannot assign int to property 
// Smartphone::$suplier of type Perusahaan
