<?php
class Produk {
}

$produk01 = new Produk();
$produk01->tambah(3, 7, 8); 
// Fatal error: Uncaught Error: Call to undefined method Produk::tambah()
