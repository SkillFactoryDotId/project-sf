<?php
abstract class Produk {
}

class Televisi extends Produk{
}

$produk01 = new Televisi();