<?php
class Laptop {
  private $merek;

  public function __construct($merek){
    $this->merek = $merek;
  }
}

$produk01 = new Laptop('Asus');
$produk02 = new Laptop('Asus');

if ($produk01 === $produk02) {
  echo "Kedua object sama!";
}
else {
  echo "Kedua object tidak sama!";
}
