<?php
abstract class Produk {
  abstract public function cekHarga(){
    return 3000000;
  } 
}

// Fatal error: Abstract function Produk::cekHarga() cannot contain body