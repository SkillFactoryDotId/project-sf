<?php
class Produk {
  private $merek = "Logitech";
  private $tipe  = "Mouse";

  public function __get($name) {
    if (($name == "merek") || ($name == "tipe")) {
      $hasil = strtoupper($this->$name);
    }
    else {
      $hasil = "Maaf property '$name' tidak terdefinisi";
    }
    return $hasil;
  }
}

$produk01 = new Produk();
echo $produk01->merek;     // LOGITECH
echo "<br>";
echo $produk01->tipe;      // MOUSE
echo "<br>";
echo $produk01->warna;     // Maaf property 'warna' tidak terdefinisi
