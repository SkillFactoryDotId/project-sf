<?php
class Smartphone {
  public ?int $merek;
}

$produk01 = new Smartphone();
$produk01->merek = null;

var_dump($produk01->merek); // NULL

