<?php
class Produk {
  public $merek;
  public $tipe;
  public $harga;

  public function __construct($merek,$tipe,$harga){
    $this->merek = $merek;
    $this->tipe = $tipe;
    $this->harga = $harga;
  }
}

class Smartphone extends Produk { }
class Televisi extends Produk { }

function tampilkanProduk(Produk $barang){
  return "Produk ".$barang->merek." ".$barang->tipe." di jual seharga Rp. "
       .number_format($barang->harga,2,",",".");
}

$produk01 = new Televisi("Samsung", "LED TV 40 inch UA40M5000",4499000);
$produk02 = new Smartphone("Samsung","Galaxy S9+",11999000);

echo tampilkanProduk($produk01);
echo "<br>";
echo tampilkanProduk($produk02);
