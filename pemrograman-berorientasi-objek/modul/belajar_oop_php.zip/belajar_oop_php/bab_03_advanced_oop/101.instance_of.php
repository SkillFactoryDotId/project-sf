<?php
class Produk {  }

interface SmartElectronic{
  public function cekOS();
}

trait LowWatt{
  public function efisiensi(){
    return "Konsumsi daya 0.8";
  }
}

class Televisi extends Produk implements SmartElectronic{
  use LowWatt;
  public function cekOS(){
    return "Android 9.0 (Pie)";
  }
}

$produk01 = new Televisi();

echo var_dump($produk01 instanceof Produk)."<br>";
echo var_dump($produk01 instanceof Televisi)."<br>";
echo var_dump($produk01 instanceof SmartElectronic)."<br>";
echo var_dump($produk01 instanceof LowWatt)."<br>";
echo var_dump($produk01 instanceof Smartphone)."<br>";
