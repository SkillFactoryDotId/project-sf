<?php
class Produk {
  public function __get($name) {
    if ($name == "merek"){
      $hasil = "Logitech";
    }
    else if ($name == "harga"){
      $hasil = 150000;
    }
    else if ($name == "tipe"){
      $hasil = "Mouse";
    }
    else {
      $hasil = "Maaf property '$name' tidak terdefinisi";
    }
    return $hasil;
  } 
}

$produk01 = new Produk();
echo $produk01->merek;    // Logitech
echo "<br>";
echo $produk01->harga;    // 150000
echo "<br>";
echo $produk01->tipe;     // Mouse
echo "<br>";
echo $produk01->warna;    // Maaf property 'warna' tidak terdefinisi