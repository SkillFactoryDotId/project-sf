<?php
class Produk {
  public function __call($name,$arguments){
    echo "Maaf method $name dengan argument ". implode(", ",$arguments);
    echo " tidak tersedia <br>";
  }
}

Produk::tambah(3, 7, 8);  
// Fatal error: Uncaught Error: Call to undefined method Produk::tambah() 