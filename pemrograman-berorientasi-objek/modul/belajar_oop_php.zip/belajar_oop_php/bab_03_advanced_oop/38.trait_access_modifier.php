<?php
trait SmartElectronic{
  public function cekOS(){
    return "Android 9.0 (Pie)";
  }
}

class SmartTV{
  use SmartElectronic { cekOS as protected; }
}

$produk01 = new SmartTV;
echo $produk01->cekOS();           
 //  Fatal error: Uncaught Error: Call to protected method SmartTV::cekOS()