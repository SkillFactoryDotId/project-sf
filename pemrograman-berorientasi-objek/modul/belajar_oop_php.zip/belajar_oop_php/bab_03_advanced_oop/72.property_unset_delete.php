<?php
class Produk {
  public $merek = "Sony";
}

$produk01 = new Produk();

echo "<pre>";
print_r($produk01);
echo "</pre>";

unset($produk01->stok);

echo "<pre>";
print_r($produk01);
echo "</pre>";