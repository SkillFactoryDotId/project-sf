<?php
class Produk {
  public $merek = "Sony";
  protected $stok = 9;
  private $tipe = "Televisi";

  public function __isset($name)  {
    echo "Apakah property '$name' kosong? ";
    var_dump(empty($this->$name));
  }
}

$produk01 = new Produk();
var_dump(empty($produk01->merek));
echo "<br>";
empty($produk01->stok);
echo "<br>";
empty($produk01->tipe);
echo "<br>";
empty($produk01->warna);