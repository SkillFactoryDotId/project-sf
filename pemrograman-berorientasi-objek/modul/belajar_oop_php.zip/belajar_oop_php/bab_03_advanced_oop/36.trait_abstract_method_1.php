<?php
trait SmartElectronic{
  public function cekOS(){
    return "Android 9.0 (Pie)";
  }
  abstract public function cekProcessor();
}

class SmartTV{
  use SmartElectronic;
}

// Fatal error: Class SmartTV contains 1 abstract method and must therefore
//  be declared abstract or implement the remaining methods (SmartTV::cekProcessor)