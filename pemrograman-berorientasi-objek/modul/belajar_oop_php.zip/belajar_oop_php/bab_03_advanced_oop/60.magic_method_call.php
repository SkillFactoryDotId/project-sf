<?php
class Produk {
  public function __call($name,$arguments){
    echo "Maaf method $name tidak tersedia";
  }
}

$produk01 = new Produk();
$produk01->tambah(3, 7, 8);     // Maaf method tambah tidak tersedia
