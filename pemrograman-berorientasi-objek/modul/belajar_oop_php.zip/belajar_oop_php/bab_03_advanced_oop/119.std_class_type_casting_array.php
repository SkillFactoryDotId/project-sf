<?php
$produk = ["merek" => "Oppo", "tipe" => "Find X", "harga" => 13499000];
$produk01 = (object) $produk;

echo $produk01->merek."<br>";
echo $produk01->tipe."<br>";
echo $produk01->harga."<br>";

var_dump($produk01 instanceof stdClass);