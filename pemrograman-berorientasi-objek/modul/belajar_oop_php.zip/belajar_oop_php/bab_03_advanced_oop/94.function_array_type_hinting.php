<?php

function hitungRata2(array $data){
  return ($data[0] + $data[1] + $data[2])/3;
}

echo hitungRata2(3, 6, 12);  // Fatal error: Uncaught TypeError: Argument 1 passed to hitungRata2() must be of the type array, integer given
