<?php
class Perusahaan {
  public function __construct(public $nama, public $kota) { 
  }
  public function getInfo(){
    return "$this->nama dari kota $this->kota";
  }
}

class Produk {
  public ?Perusahaan $suplier;

  public function __construct($suplier) { 
    $this->suplier = $suplier;
  }
}

$perusahaan01 = new Perusahaan("PT. ABC","Bandung");
$produk01 = new Produk($perusahaan01);

echo $produk01->suplier->getInfo();    // PT. ABC dari kota Bandung