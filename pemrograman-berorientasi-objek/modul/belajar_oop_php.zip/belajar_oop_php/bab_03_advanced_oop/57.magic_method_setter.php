<?php
class Produk {
  private $merek;
  private $harga;

  public function __set($name, $value) {
    if ($name == "merek"){
      if (is_string($value)) {
        $this->merek = $value;
      }
      else {
        echo "Error: merek harus berbentuk string <br>";
      }
    }

    else if ($name == "harga"){
      if (is_int($value)) {
        $this->harga = $value;
      }
      else {
        echo "Error: harga harus berbentuk angka <br>";
      }
    }

    else {
      echo "Maaf property '$name' tidak tersedia";
    }
  } 
}

$produk01 = new Produk();
$produk01->merek = "Logitech";
$produk01->harga = 15000;

echo "<pre>";
print_r ($produk01);
echo "</pre>";