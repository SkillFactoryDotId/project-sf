<?php
function tampilkanSmartphone($hp){
  return "Smartphone ".$hp->merek." ".$hp->tipe." di jual seharga Rp. "
       .number_format($hp->harga,2,",",".");
}

echo tampilkanSmartphone(new class{
  public $merek= "Vivo";
  public $tipe= "V11";
  public $harga= "3599000";
});