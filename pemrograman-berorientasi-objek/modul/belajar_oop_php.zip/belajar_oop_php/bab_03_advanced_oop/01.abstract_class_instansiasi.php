<?php
abstract class Produk {
}

$produk01 = new Produk();
// Fatal error: Uncaught Error: Cannot instantiate abstract class Produk