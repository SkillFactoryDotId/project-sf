<?php
abstract class Produk {
  abstract public function cekHarga();  
}

class Televisi extends Produk{
  protected function cekHarga(){
    return 3000000;
  }
}

$produk01 = new Televisi();
// Fatal error: Access level to Televisi::cekHarga() must be public (as in class Produk)