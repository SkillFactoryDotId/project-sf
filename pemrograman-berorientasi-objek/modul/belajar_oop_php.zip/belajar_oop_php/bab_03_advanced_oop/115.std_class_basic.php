<?php
$produk01 = new stdClass;
var_dump($produk01);