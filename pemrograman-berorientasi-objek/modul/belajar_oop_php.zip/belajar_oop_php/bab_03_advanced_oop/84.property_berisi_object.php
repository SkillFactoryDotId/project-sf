<?php
class Perusahaan {
  public $nama;

  public function __construct($nama){
    $this->nama = $nama;
  }
}

class Laptop {
  public $merek;
  public $suplier;

  public function __construct($merek){
    $this->merek = $merek;
  }
}

$suplierLaptop = new Perusahaan("CV. Jaya Abadi");
$produk01 = new Laptop("Acer");
$produk01->suplier = $suplierLaptop;

echo "<pre>";
print_r($produk01);
echo "</pre>";