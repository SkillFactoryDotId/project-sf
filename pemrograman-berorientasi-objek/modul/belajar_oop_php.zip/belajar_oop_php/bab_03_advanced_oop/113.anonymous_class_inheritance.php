<?php
class Produk {
  protected $merek;

  public function __construct($foo){
    $this->merek = $foo;
  }
}

interface PunyaMerek {
  public function getMerek();
}

$produk01 = new class("Hitachi") extends Produk implements PunyaMerek{
  public function getMerek(){
    return $this->merek;
  }
};

echo $produk01->getMerek();  // Hitachi
