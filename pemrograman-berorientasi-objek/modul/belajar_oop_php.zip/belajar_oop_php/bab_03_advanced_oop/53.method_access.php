<?php
class Produk {
}

$produk01 = new Produk();
$produk01->merek = "Logitech";
echo $produk01->merek;  // "Logitech"
