<?php
trait SmartElectronic{
  public static $internet = "Telkom Indihome";
  public static function cekOS(){
    return "Android 9.0 (Pie)";
  }
}

echo SmartElectronic::$internet;    //  Telkom Indihome
echo "<br>";
echo SmartElectronic::cekOS();      //  Android 9.0 (Pie)