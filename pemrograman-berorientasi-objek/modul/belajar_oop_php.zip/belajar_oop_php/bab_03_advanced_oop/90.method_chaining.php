<?php

class Televisi {
  private $merek;
  private $jenisLayar;
  private $ukuranLayar;

  public function setMerek($merek){
    $this->merek = $merek;
    return $this;
  }
  public function setJenisLayar($jenisLayar){
    $this->jenisLayar = $jenisLayar;
    return $this;
  }
  public function setUkuranLayar($ukuranLayar){
    $this->ukuranLayar = $ukuranLayar;
    return $this;
  }

  public function cekInfo(){
    return "Televisi ".$this->jenisLayar." ".$this->merek." ".
           $this->ukuranLayar." inch";
  }

}

$produk01 = new Televisi();
echo $produk01->setMerek("Samsung")->setJenisLayar("LED")->setUkuranLayar("42")->cekInfo();
