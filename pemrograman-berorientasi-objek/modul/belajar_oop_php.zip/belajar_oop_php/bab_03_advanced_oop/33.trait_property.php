<?php
trait SmartElectronic{
  public $internet = "Telkom Indihome";
  public function cekOS(){
    return "Android 9.0 (Pie)";
  }
}

class SmartTV{
  use SmartElectronic;
}

$produk01 = new SmartTV;
echo $produk01->internet;    //  Telkom Indihome
echo "<br>";
echo $produk01->cekOS();     //  Android 9.0 (Pie)
