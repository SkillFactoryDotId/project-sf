<?php
$produk01 = new class(){
  private $merek = "Polytron";
  public function getMerek(){
    return $this->merek;
  }
};

echo $produk01->getMerek();  // Polytron
echo $produk01->merek;       // Fatal error: Uncaught Error: Cannot access private property class@anonymous::$merek