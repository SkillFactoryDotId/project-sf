<?php
class Produk {
  public function __toString(){
    return "Ini berasal dari class Produk";
  }
}

class Televisi extends Produk {
}

$produk01 = new Televisi();
echo $produk01;  // Ini berasal dari class Produk
