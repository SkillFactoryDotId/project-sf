<?php
echo "Kode ini berada di file: ".__FILE__."<br><br>";
echo "Yang berada di dalam folder: ".__DIR__."<br><br>";
echo "Perintah ini berasal dari baris: ".__LINE__."<br><br>";

function belajar_magic_constant(){
  return "Kode ini berada di dalam fungsi: ".__FUNCTION__;
}

echo belajar_magic_constant();
