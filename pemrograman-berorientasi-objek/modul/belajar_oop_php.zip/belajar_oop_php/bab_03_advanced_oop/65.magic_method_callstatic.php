<?php
class Produk {
  public static function __callStatic($name,$arguments){
    echo "Maaf method static $name dengan argument ". implode(", ",$arguments);
    echo " tidak tersedia <br>";
  }
}

Produk::tambah(3, 7, 8);  
// Maaf method tambah dengan argument 3, 7, 8 tidak tersedia 