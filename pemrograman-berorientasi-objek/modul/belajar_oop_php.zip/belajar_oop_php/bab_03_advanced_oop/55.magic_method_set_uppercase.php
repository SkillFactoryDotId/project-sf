<?php
class Produk {
  public function __set($name, $value) {
    $this->$name = strtoupper($value);
  } 
}

$produk01 = new Produk();
$produk01->merek = "Logitech";
$produk01->harga = 15000;
$produk01->tipe = "Mouse";

echo $produk01->merek;   // LOGITECH
echo "<br>";
echo $produk01->harga;   // 15000
echo "<br>";
echo $produk01->tipe;    // MOUSE