<?php
abstract class Produk {
  abstract private function cekHarga();
}

// Fatal error: Abstract function Produk::cekHarga() cannot be declared private
