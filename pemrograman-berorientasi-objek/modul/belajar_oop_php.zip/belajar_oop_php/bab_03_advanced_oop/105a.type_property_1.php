<?php
class Smartphone {
  public string $merek;
}

$produk01 = new Smartphone();
$produk01->merek = "Oppo";

echo $produk01->merek; // Oppo
