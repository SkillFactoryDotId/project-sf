<?php
class Smartphone {
  public $merek;
  public $tipe;
  public $harga;

  public function __construct($merek,$tipe,$harga){
    $this->merek = $merek;
    $this->tipe = $tipe;
    $this->harga = $harga;
  }
}

function tampilkanSmartphone($hp){
  return "Smartphone ".$hp->merek." ".$hp->tipe." di jual seharga Rp. "
       .number_format($hp->harga,2,",",".");
}

$produk01 = new Smartphone("Xiaomi","Redmi Note 6",2799000);
$produk02 = new Smartphone("Samsung","Galaxy S9+",11999000);
$produk03 = new Smartphone("Apple","iPhone X",15700000);

echo tampilkanSmartphone($produk01);
echo "<br>";
echo tampilkanSmartphone($produk02);
echo "<br>";
echo tampilkanSmartphone($produk03);
