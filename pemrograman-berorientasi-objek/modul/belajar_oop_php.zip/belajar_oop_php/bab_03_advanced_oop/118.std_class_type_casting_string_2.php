<?php
$foo = "Belajar OOP PHP";
$bar = (object) $foo;

echo $bar->scalar; // Belajar OOP PHP