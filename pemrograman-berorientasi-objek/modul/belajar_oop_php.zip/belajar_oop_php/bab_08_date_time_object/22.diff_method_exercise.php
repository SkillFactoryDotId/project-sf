<?php
date_default_timezone_set("Asia/Jakarta");

$sekarang = new DateTime();
$tanggalLahir = new DateTime('15-07-1998 20:45:52');

$format = '%y tahun %m bulan %d hari %h jam %i menit %s detik';
echo $sekarang->diff($tanggalLahir)->format($format);
