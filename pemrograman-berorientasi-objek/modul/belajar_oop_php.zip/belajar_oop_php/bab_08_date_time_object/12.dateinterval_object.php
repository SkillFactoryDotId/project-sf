<?php
$sekarang = new DateTime(null, new DateTimeZone('Asia/Jakarta'));
$durasi = new DateInterval('P3Y1M2W');
$sekarang->add($durasi);

echo $sekarang->format('j F Y');    // 23 May 2025

echo "<br>";

$sekarang = new DateTime(null, new DateTimeZone('Asia/Jakarta'));
$durasi = new DateInterval('P300D');
$sekarang->add($durasi);

echo $sekarang->format('j F Y');    // 3 February 2023
