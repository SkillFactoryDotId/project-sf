<?php
$sekarang = new DateTime(null, new DateTimeZone('Asia/Jakarta'));
echo "Waktu WIB: ".$sekarang->format('d-m-Y, H:i:s');

echo "<br>";

$sekarang = new DateTime(null, new DateTimeZone('Asia/Makassar'));
echo "Waktu WITA: ". $sekarang->format('d-m-Y, H:i:s');

echo "<br>";

$sekarang = new DateTime(null, new DateTimeZone('Asia/Jayapura'));
echo "Waktu WIT: ". $sekarang->format('d-m-Y, H:i:s');
