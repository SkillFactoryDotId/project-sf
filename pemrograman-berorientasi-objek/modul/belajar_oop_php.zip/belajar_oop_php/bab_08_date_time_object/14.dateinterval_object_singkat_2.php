<?php
$sekarang = new DateTime(null, new DateTimeZone('Asia/Jakarta'));
echo $sekarang->add(new DateInterval('P3Y1M2W'))->format('j F Y');
// 23 May 2025

echo "<br>";

$sekarang = new DateTime(null, new DateTimeZone('Asia/Jakarta'));
echo $sekarang->add(new DateInterval('P300D'))->format('j F Y');
// 3 February 2023
