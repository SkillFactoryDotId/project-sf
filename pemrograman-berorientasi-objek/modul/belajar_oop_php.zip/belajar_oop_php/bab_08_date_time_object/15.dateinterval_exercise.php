<?php
$sekarang = new DateTime(null, new DateTimeZone('Asia/Jakarta'));
$durasi = new DateInterval('P1000D');
echo $sekarang->add($durasi)->format('l, j F Y H:i:s');
// Friday, 3 January 2025 12:05:16

echo "<br>";

$hariKemerdekaan = new DateTime('17-08-1945 10:30', new DateTimeZone('Asia/Jakarta'));
$durasi = new DateInterval('P9Y9M9DT9H9M9S');

echo $hariKemerdekaan->add($durasi)->format('l, j F Y H:i:s');
// Thursday, 26 May 1955 19:39:09
