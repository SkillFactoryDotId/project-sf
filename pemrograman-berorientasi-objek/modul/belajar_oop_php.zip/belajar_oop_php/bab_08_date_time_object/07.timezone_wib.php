<?php
$zonaWIB = new DateTimeZone('Asia/Jakarta');
$sekarang = new DateTime('now', $zonaWIB);

echo $sekarang->format('d-m-Y, H:i:s');   // 09-04-2022, 11:59:04
