<?php
$sekarang = new DateTime();

echo $sekarang->format('d-m-Y');  // 09-04-2022
