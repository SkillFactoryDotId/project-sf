<?php
date_default_timezone_set("Asia/Jakarta");

$sekarang = new DateTime();
$sekarang->add(new DateInterval('P2W'));
$sekarang->modify('-1 month');
echo $sekarang->format('j F Y');
