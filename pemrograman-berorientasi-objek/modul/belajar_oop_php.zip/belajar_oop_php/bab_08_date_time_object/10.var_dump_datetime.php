<?php
$sekarang = new DateTime();

echo "<pre>";
var_dump($sekarang);
echo "</pre>";
