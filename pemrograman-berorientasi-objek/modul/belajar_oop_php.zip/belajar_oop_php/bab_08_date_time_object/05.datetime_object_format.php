<?php
$sekarang = new DateTime();

echo $sekarang->format('d-m-Y');          echo "<br>";  // 09-04-2022
echo $sekarang->format('d/m/Y');          echo "<br>";  // 09/04/2022
echo $sekarang->format('D, d M Y');       echo "<br>";  // Sat, 09 Apr 2022
echo $sekarang->format('j F y');          echo "<br>";  // 9 April 22
echo $sekarang->format('d-m-Y, H:i:s');   echo "<br>";  // 09-04-2022, 11:44:28
