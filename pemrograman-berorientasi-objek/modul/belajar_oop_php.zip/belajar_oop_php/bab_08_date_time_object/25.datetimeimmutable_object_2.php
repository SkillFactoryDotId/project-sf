<?php
date_default_timezone_set("Asia/Jakarta");

$sekarang = new DateTimeImmutable();
$hasil1 = $sekarang->add(new DateInterval('P2W'));
echo $hasil1->format('j F Y');

echo "<br>";

$hasil2 = $sekarang->modify('-1 month');
echo $hasil2->format('j F Y');
