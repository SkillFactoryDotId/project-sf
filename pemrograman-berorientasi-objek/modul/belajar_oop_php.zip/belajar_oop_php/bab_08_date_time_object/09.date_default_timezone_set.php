<?php
date_default_timezone_set("Asia/Jakarta");

$sekarang = new DateTime();
echo $sekarang->format('d-m-Y, H:i:s');    // 09-04-2022, 12:00:53
