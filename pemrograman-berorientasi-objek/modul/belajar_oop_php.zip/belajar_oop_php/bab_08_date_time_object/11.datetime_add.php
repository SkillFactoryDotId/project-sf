<?php
$sekarang = new DateTime(null, new DateTimeZone('Asia/Jakarta'));
$duaMinggu = new DateInterval('P2W');
$sekarang->add($duaMinggu);

echo $sekarang->format('j F Y');    // 23 April 2022
