<?php
$sekarang = new DateTime();
echo $sekarang->format('d-m-Y, H:i:s');    // 09-04-2022, 06:56:33
