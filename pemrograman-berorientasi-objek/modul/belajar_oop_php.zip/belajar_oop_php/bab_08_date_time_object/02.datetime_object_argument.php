<?php
$sekarang = new DateTime(null);
echo $sekarang->format('d-m-Y');         // 09-04-2022

echo "<br>";

$sekarang = new DateTime('now');
echo $sekarang->format('d-m-Y');         // 09-04-2022

echo "<br>";

$hariKemerdekaan = new DateTime('17 Aug 1945');
echo $hariKemerdekaan->format('d-m-Y');  // 17-08-1945

echo "<br>";

$akhirTahun = new DateTime('2022/12/31');
echo $akhirTahun->format('d-m-Y');       // 31-12-2022
