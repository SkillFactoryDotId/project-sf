<?php
date_default_timezone_set("Asia/Jakarta");

$tanggal1 = new DateTime('12-08-2016');
$tanggal2 = new DateTime('25-06-2022');

$interval = $tanggal1->diff($tanggal2);
echo $interval->format('%a hari');      // 2143 hari