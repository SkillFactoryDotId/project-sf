<?php
$tgl1 = new DateTime('17 Aug 2022');
$tgl2 = new DateTime('17 Aug 1945');

var_dump($tgl1 < $tgl2);        echo "<br>";
var_dump($tgl1 > $tgl2);        echo "<br>";
var_dump($tgl1 === $tgl2);      echo "<br>";