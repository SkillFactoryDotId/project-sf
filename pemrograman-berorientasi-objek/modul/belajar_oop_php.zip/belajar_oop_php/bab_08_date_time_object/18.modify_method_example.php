<?php
date_default_timezone_set("Asia/Jakarta");

$sekarang = new DateTime();
echo $sekarang->modify('+10 month +100 day')->format('j F Y');

echo "<br>";

$merdeka = new DateTime('17-08-1945 10:30');
echo $merdeka->modify('-3 day -10 hour -10 minute')->format('D, j F Y H:i:s');