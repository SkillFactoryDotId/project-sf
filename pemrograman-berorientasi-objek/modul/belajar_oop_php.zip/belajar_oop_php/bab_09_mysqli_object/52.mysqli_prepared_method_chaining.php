<?php
mysqli_report(MYSQLI_REPORT_STRICT);

try {
  $mysqli = new mysqli("localhost", "root", "","ilkoom");

  // Buat prepared statement untuk ambil data barang
  $stmt = $mysqli->prepare("SELECT * FROM barang WHERE id_barang = ?");

  // Proses bind
  $stmt->bind_param("i", $id_barang);
  $id_barang = 3;

  // Proses execute
  $stmt->execute();

  // Proses menampilkan hasil query
  $row = $stmt->get_result()->fetch_object();
  echo $row->id_barang;       echo " | ";
  echo $row->nama_barang;     echo " | ";
  echo $row->jumlah_barang;   echo " | ";
  echo $row->harga_barang;    echo " | ";
  echo $row->tanggal_update;

  $stmt->free_result();
  $stmt->close();
}
catch (Exception $e) {
  echo "Koneksi / Query bermasalah: ".$e->getMessage(). " (".$e->getCode().")";
}
finally {
  if (isset($mysqli)) {
    $mysqli->close();
  }
}
