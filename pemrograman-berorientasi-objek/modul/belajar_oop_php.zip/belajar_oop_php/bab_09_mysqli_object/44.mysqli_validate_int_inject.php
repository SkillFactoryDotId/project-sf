<?php
mysqli_report(MYSQLI_REPORT_STRICT);

$_GET['id_barang'] = "5 OR id_barang = 2";
$id_barang = $_GET['id_barang'];

try {
  $mysqli = new mysqli("localhost", "root", "","ilkoom");
  
  // Ambil data di tabel barang
  $query = "SELECT * FROM barang WHERE id_barang = $id_barang";
  $result = $mysqli->query($query);

  while ($row = $result->fetch_assoc()){
    echo $row['id_barang'];       echo " | ";
    echo $row['nama_barang'];     echo " | ";
    echo $row['jumlah_barang'];   echo " | ";
    echo $row['harga_barang'];    echo " | ";
    echo $row['tanggal_update'];  
    echo "<br>";
  }
  $result->free();
}
catch (Exception $e) {
  echo "Koneksi / Query bermasalah: ".$e->getMessage(). " (".$e->getCode().")";
}
finally {
  if (isset($mysqli)) {
    $mysqli->close();
  }
}
