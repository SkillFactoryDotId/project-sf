<?php
mysqli_report(MYSQLI_REPORT_STRICT);

try {
  $mysqli = new mysqli("localhost", "root", "","ilkoom");

  // Generate tanggal hari ini
  $sekarang = new DateTime('now', new DateTimeZone('Asia/Jakarta'));
  $timestamp = $sekarang->format("Y-m-d H:i:s");

  // Jalankan 3bh query
  $query = "INSERT INTO barang
    (nama_barang, jumlah_barang, harga_barang, tanggal_update)
    VALUES ('Hardisk Eksternal WD My Passport 2TB',9,1120000,'$timestamp');
    UPDATE barang SET jumlah_barang = 5, tanggal_update = '$timestamp'
    WHERE id_barang=3;
    UPDATE barang SET harga_barang = 4500000, tanggal_update = '$timestamp'
    WHERE id_barang=5";

  $mysqli->multi_query($query);
  echo "Terdapat ".$mysqli->affected_rows." baris yang ditambah <br>";

  // Proses sinkronisasi dengan MySQL (akibat $mysqli->multi_query)
  while( $mysqli->more_results())
  {
    $mysqli->next_result();
  }

  // Ambil semua data di tabel barang
  $query = "SELECT * FROM barang";
  $result = $mysqli->query($query);
  if ($mysqli->error){
    throw new Exception($mysqli->error, $mysqli->errno);
  }
  else {
    $arr = $result->fetch_all(MYSQLI_ASSOC);
  }
}
catch (Exception $e) {
  echo "Koneksi / Query bermasalah: ".$e->getMessage(). " (".$e->getCode().")";
}
finally {
  if (isset($mysqli)) {
    $mysqli->close();
  }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Menampilkan Tabel MySQL</title>
  <style>
    table {
      border-collapse: collapse;
    }
    td, th {
      border-bottom: 1px solid black;
    }
    th,td {
      padding: 10px 15px;
    }
    tr:nth-child(even) {background-color: #f2f2f2;}
  </style>
</head>
<body>
<table>
  <tr>
    <th>ID</th>
    <th>Nama</th>
    <th>Stok</th>
    <th>Harga</th>
    <th>Update</th>
  </tr>
  <?php foreach ($arr as $key => $val) {?>
  <tr>
    <td><?php echo $val['id_barang']; ?></td>
    <td><?php echo $val['nama_barang']; ?></td>
    <td><?php echo $val['jumlah_barang']; ?></td>
    <td><?php echo $val['harga_barang']; ?></td>
    <td><?php echo $val['tanggal_update']; ?></td>
  </tr>
  <?php } ?>
</table>
</body>
</html>
