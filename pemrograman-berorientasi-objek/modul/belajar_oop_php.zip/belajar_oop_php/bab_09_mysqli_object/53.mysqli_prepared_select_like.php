<?php
mysqli_report(MYSQLI_REPORT_STRICT);

try {
  $mysqli = new mysqli("localhost", "root", "","ilkoom");

  // Buat prepared statement untuk mencari nama barang
  $stmt = $mysqli->prepare("SELECT * FROM barang WHERE nama_barang LIKE ? ");

  // Proses bind
  $stmt->bind_param("s", $nama_barang);
  $nama_barang = "%kulkas%";
  
  // Proses execute
  $stmt->execute();

  // Proses menampilkan hasil query
  $result = $stmt->get_result();
  while ($row = $result->fetch_assoc()){
    echo $row['id_barang'];       echo " | ";
    echo $row['nama_barang'];     echo " | ";
    echo $row['jumlah_barang'];   echo " | ";
    echo $row['harga_barang'];    echo " | ";
    echo $row['tanggal_update'];
    echo "<br>";
  }

  $stmt->free_result();
  $stmt->close();
}
catch (Exception $e) {
  echo "Koneksi / Query bermasalah: ".$e->getMessage(). " (".$e->getCode().")";
}
finally {
  if (isset($mysqli)) {
    $mysqli->close();
  }
}
