<?php
mysqli_report(MYSQLI_REPORT_STRICT);

try {
  $mysqli = new mysqli("localhost", "root", "","ilkoom");

  // Buat prepared statement untuk ambil data barang
  $stmt = $mysqli->prepare("SELECT * FROM barang WHERE id_barang = ?");

  // Proses bind
  $stmt->bind_param("i", $id_barang);
  $id_barang = 5;

  // Proses execute
  $stmt->execute();

  // Proses menampilkan hasil query
  $stmt->bind_result($a, $b, $c, $d, $e);
  $stmt->fetch();

  echo $a." | ". $b." | ". $c." | ". $d." | ". $e;

  $stmt->free_result();
  $stmt->close();
}
catch (Exception $e) {
  echo "Koneksi / Query bermasalah: ".$e->getMessage(). " (".$e->getCode().")";
}
finally {
  if (isset($mysqli)) {
    $mysqli->close();
  }
}
