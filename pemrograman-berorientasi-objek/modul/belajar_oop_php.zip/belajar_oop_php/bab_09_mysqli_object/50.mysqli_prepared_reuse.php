<?php
mysqli_report(MYSQLI_REPORT_STRICT);

try {
  $mysqli = new mysqli("localhost", "root", "","ilkoom");

  // Buat prepared statement untuk ambil data barang
  $query = "SELECT * FROM barang WHERE id_barang = ?";
  $stmt = $mysqli->prepare($query);

  // Proses bind
  $stmt->bind_param("i", $id_barang);

  // Input data 1
  $id_barang = 2;
  $stmt->execute();
  $result = $stmt->get_result();
  $row = $result->fetch_row();
  echo $row[0]." | ".$row[1]. " | ".$row[2]. " | ".$row[3]. " | ".$row[4];
  $stmt->free_result();

  echo "<br>";

  // Input data 2
  $id_barang = 4;
  $stmt->execute();
  $result = $stmt->get_result();
  $row = $result->fetch_row();
  echo $row[0]." | ".$row[1]. " | ".$row[2]. " | ".$row[3]. " | ".$row[4];
  $stmt->free_result();

  $stmt->close();
}
catch (Exception $e) {
  echo "Koneksi / Query bermasalah: ".$e->getMessage(). " (".$e->getCode().")";
}
finally {
  if (isset($mysqli)) {
    $mysqli->close();
  }
}
