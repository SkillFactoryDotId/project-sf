<?php
mysqli_report(MYSQLI_REPORT_STRICT);

try {
  $mysqli = new mysqli("localhost", "root", "","ilkoom");

  // Tampilkan data dari tabel barang
  $query = "SELECT * FROM barang WHERE id_barang = 1";
  $result = $mysqli->query($query);

  // Tampilkan jumlah baris dan kolom
  echo "Terdapat ".$result->field_count." kolom dan ".$result->num_rows." baris";
  $result->free();
}
catch (Exception $e) {
  echo "Koneksi / Query bermasalah: ".$e->getMessage(). " (".$e->getCode().")";
}
finally {
  if (isset($mysqli)) {
    $mysqli->close();
  }
}
