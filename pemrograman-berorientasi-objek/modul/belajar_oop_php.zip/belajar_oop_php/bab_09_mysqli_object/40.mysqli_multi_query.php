<?php
mysqli_report(MYSQLI_REPORT_STRICT);

try {
  $mysqli = new mysqli("localhost", "root", "","ilkoom");

  // Generate tanggal hari ini
  $sekarang = new DateTime('now', new DateTimeZone('Asia/Jakarta'));
  $timestamp = $sekarang->format("Y-m-d H:i:s");

  // Jalankan 3bh query
  $query = "INSERT INTO barang
    (nama_barang, jumlah_barang, harga_barang, tanggal_update)
    VALUES ('Hardisk Eksternal WD My Passport 2TB',9,1120000,'$timestamp');
    UPDATE barang SET jumlah_barang = 5, tanggal_update = '$timestamp'
    WHERE id_barang=3;
    UPDATE barang SET harga_barang = 4500000, tanggal_update = '$timestamp'
    WHERE id_barang=5";

  $mysqli->multi_query($query);
  echo "Terdapat ".$mysqli->affected_rows." baris yang ditambah <br>";
}
catch (Exception $e) {
  echo "Koneksi / Query bermasalah: ".$e->getMessage(). " (".$e->getCode().")";
}
finally {
  if (isset($mysqli)) {
    $mysqli->close();
  }
}
