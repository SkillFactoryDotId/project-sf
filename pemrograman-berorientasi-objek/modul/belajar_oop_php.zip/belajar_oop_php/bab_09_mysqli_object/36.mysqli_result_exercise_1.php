<?php
mysqli_report(MYSQLI_REPORT_STRICT);

try {
  $mysqli = new mysqli("localhost", "root", "","ilkoom");

  // Ambil semua data di tabel barang
  $query = "SELECT * FROM barang";
  $result = $mysqli->query($query);

  $i=0;
  while ($row = $result->fetch_array(MYSQLI_ASSOC)){
    $arr[$i]['id_barang'] = $row['id_barang'];
    $arr[$i]['nama_barang'] = $row['nama_barang'];
    $arr[$i]['jumlah_barang'] = $row['jumlah_barang'];
    $arr[$i]['harga_barang'] = $row['harga_barang'];
    $arr[$i]['tanggal_update']= $row['tanggal_update'];
    $i++;
  }
  $result->free();
}
catch (Exception $e) {
  echo "Koneksi / Query bermasalah: ".$e->getMessage(). " (".$e->getCode().")";
}
finally {
  if (isset($mysqli)) {
    $mysqli->close();
  }
}

echo "<pre>";
print_r($arr);
echo "</pre>";

?>
