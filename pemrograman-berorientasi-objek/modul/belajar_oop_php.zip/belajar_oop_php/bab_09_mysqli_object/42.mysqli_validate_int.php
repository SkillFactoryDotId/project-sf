<?php
mysqli_report(MYSQLI_REPORT_STRICT);

try {
  $mysqli = new mysqli("localhost", "root", "","ilkoom");
  
  // Ambil data di tabel barang
  $query = "SELECT * FROM barang WHERE id_barang = 5";
  $result = $mysqli->query($query);
  
  while ($row = $result->fetch_assoc()){
    echo $row['id_barang'];       echo " | ";
    echo $row['nama_barang'];     echo " | ";
    echo $row['jumlah_barang'];   echo " | ";
    echo $row['harga_barang'];    echo " | ";
    echo $row['tanggal_update'];  
    echo "<br>";
  }
  $result->free();
}
catch (Exception $e) {
  echo "Koneksi / Query bermasalah: ".$e->getMessage(). " (".$e->getCode().")";
}
finally {
  if (isset($mysqli)) {
    $mysqli->close();
  }
}
