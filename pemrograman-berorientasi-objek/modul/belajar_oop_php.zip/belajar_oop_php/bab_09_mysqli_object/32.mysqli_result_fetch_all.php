<?php
mysqli_report(MYSQLI_REPORT_STRICT);

try {
  $mysqli = new mysqli("localhost", "root", "","ilkoom");

  // Ambil semua data di tabel barang
  $query = "SELECT * FROM barang";
  $result = $mysqli->query($query);

  $arr = $result->fetch_all();
  echo "<pre>";
  print_r($arr);
  echo "</pre>";

  $result->free();
}
catch (Exception $e) {
  echo "Koneksi / Query bermasalah: ".$e->getMessage(). " (".$e->getCode().")";
}
finally {
  if (isset($mysqli)) {
    $mysqli->close();
  }
}
