<?php
$mysqli = new mysqli("localhost", "root", "");

// Perintah query MySQL
// Perintah query MySQL
// Perintah query MySQL

$mysqli->close();
