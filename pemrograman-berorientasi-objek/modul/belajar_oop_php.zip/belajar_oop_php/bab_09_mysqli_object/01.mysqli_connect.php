<?php
$mysqli = new mysqli("localhost", "root", "");

echo "<pre>";
print_r($mysqli);
echo "</pre>";
