<?php
$mysqli = new mysqli("localhost", "root", "");

echo $mysqli->affected_rows;  echo "<br>";
echo $mysqli->client_info;    echo "<br>";
echo $mysqli->connect_errno;  echo "<br>";
echo $mysqli->server_info;    echo "<br>";
