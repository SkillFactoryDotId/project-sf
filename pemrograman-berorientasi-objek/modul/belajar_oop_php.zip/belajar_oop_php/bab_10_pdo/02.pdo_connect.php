<?php
$pdo = new PDO("mysql:host=localhost", "root", "");
var_dump($pdo);  // object(PDO)#1 (0) { } 