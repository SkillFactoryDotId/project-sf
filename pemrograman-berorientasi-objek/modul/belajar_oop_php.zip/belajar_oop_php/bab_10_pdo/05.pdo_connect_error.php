<?php

$pdo = new PDO("mysql:host=localhost;dbname=ilkoom", "root", "r4has!a");
error_reporting(0);
