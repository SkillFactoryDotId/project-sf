<?php
class Produk { }
interface LaptopGaming { }
trait LowWatt { }

class Laptop extends Produk implements LaptopGaming{ 
  use LowWatt;

  public $merek = "Asus";
  public $tipe = "ROG GX800";
  protected $harga = 95000000;

  public function getMerek() {
    return $this->merek;
  }

  public function cekInfo() {
    return $this->merek." ".$this->tipe." ".$this->harga;
  }
}

echo "<b>class_exists('Laptop')</b>: ";
var_dump(class_exists('Laptop'));
echo "<br>";

echo "<b>class_exists('Televisi')</b>: ";
var_dump(class_exists('Televisi'));
echo "<br>";

echo "<b>class_exists('PDO')</b>: ";
var_dump(class_exists('PDO'));
echo "<br>";

echo "<hr>";

echo "<b>interface_exists('LaptopGaming')</b>: ";
var_dump(interface_exists('LaptopGaming'));
echo "<br>";

echo "<b>interface_exists('SmartphoneGaming')</b>: ";
var_dump(interface_exists('SmartphoneGaming'));
echo "<br>";

echo "<b>interface_exists('Traversable')</b>: ";
var_dump(interface_exists('Traversable'));
echo "<br>";

echo "<hr>";

echo "<b>trait_exists('LowWatt')</b>: ";
var_dump(trait_exists('LowWatt'));
echo "<br>";

echo "<b>trait_exists('HighPerformance')</b>: ";
var_dump(trait_exists('HighPerformance'));
echo "<br>";

echo "<hr>";

echo "<b>property_exists('Laptop','merek')</b>: ";
var_dump(property_exists('Laptop','merek'));
echo "<br>";

echo "<b>property_exists('Laptop','harga')</b>: ";
var_dump(property_exists('Laptop','harga'));
echo "<br>";

echo "<b>property_exists('mysqli','affected_rows')</b>: ";
var_dump(property_exists('mysqli','affected_rows'));
echo "<br>";

echo "<hr>";

echo "<b>method_exists('Laptop','getMerek')</b>: ";
var_dump(method_exists('Laptop','getMerek'));
echo "<br>";

echo "<b>method_exists('Laptop','getHarga')</b>: ";
var_dump(method_exists('Laptop','getHarga'));
echo "<br>";

echo "<b>method_exists('PDO','query')</b>: ";
var_dump(method_exists('PDO','query'));
echo "<br>";