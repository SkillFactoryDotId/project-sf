<?php
class Produk { }
$produk01 = new Produk;
$produk02 = [1, 2, 3];

var_dump(is_object($produk01));
echo "<br>";
var_dump(is_object($produk02));
