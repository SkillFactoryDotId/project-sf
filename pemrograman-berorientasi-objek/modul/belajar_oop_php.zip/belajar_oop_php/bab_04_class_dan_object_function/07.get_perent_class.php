<?php
class Produk { }
class Komputer extends Produk { }
class Laptop extends Komputer { }

echo "<b>Get Class</b>: ";
print_r(get_parent_class("Laptop"));
echo "<br>";

echo "<b>Get Class</b>: ";
var_dump(get_parent_class("Produk"));
echo "<br>";