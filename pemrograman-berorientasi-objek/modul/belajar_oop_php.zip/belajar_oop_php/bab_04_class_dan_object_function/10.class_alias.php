<?php
class Produk { }

class_alias('Produk', 'Barang');

$produk01 = new Produk;
$barang01 = new Barang;

var_dump($produk01 == $barang01);
echo "<br>";

var_dump($produk01 instanceof Produk);
echo "<br>";
var_dump($produk01 instanceof Barang);
echo "<br>";
var_dump($barang01 instanceof Produk);
echo "<br>";
var_dump($barang01 instanceof Barang);
