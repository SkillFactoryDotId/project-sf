<?php
class Produk { }
interface LaptopGaming { }
class Laptop extends Produk implements LaptopGaming { }

$laptop01 = new Laptop;

var_dump($laptop01 instanceof Laptop);
echo "<br>";
var_dump($laptop01 instanceof Produk);
echo "<br>";
var_dump($laptop01 instanceof LaptopGaming);
echo "<br>";
var_dump($laptop01 instanceof Televisi);