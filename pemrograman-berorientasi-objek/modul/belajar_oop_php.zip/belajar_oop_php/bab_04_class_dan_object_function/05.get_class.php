<?php
class Produk { 
  public $merek = "Asus";
  public $tipe = "ROG GX800";
  protected $harga = 95000000;

  public function getMerek() {
    return $this->merek;
  }

  public function cekInfo() {
    return $this->merek." ".$this->tipe." ".$this->harga;
  }
}

$produk01 = new Produk;

echo "<b>Get Class</b>: ";
print_r(get_class($produk01));
echo "<br>";

echo "<b>Get Class Vars</b>: ";
print_r(get_class_vars("Produk"));
echo "<br>";

echo "<b>Get Class Methods</b>: ";
print_r(get_class_methods("Produk"));
echo "<br>";

echo "<b>Get Object Vars</b>: ";
print_r(get_object_vars($produk01));
echo "<br>";
