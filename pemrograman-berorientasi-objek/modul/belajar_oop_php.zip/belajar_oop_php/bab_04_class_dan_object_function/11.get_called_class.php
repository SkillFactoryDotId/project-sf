<?php
class Produk {
  public static function getInfo(){
    return get_called_class();
  }
}

class MesinCuci extends Produk {
}

echo Produk::getInfo();
echo "<br>";
echo MesinCuci::getInfo();