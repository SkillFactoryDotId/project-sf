<?php
class Produk { }
interface LaptopGaming { }
class Laptop extends Produk implements LaptopGaming { }

$laptop01 = new Laptop;

var_dump(is_subclass_of($laptop01,"Laptop"));
echo "<br>";
var_dump(is_subclass_of($laptop01,"Produk"));
echo "<br>";
var_dump(is_subclass_of($laptop01,"LaptopGaming"));
echo "<br>";
var_dump(is_subclass_of($laptop01,"Televisi"));
