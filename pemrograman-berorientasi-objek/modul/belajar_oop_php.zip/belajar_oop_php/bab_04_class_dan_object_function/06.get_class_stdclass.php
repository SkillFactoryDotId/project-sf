<?php
$foo = "Belajar OOP PHP";
$bar = (object) $foo;

echo get_class($bar); // stdClass
