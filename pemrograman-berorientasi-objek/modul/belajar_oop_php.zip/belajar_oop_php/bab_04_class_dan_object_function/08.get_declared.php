<?php
class Produk { }
interface LaptopGaming { }
trait LowWatt { }

class Laptop extends Produk implements LaptopGaming{ }

echo "<h1>Get Declared Class</h1>";
echo "<pre>";
print_r(get_declared_classes());
echo "</pre>";
echo "<br><hr>";

echo "<h1>Get Declared Interface</h1>";
echo "<pre>";
print_r(get_declared_interfaces());
echo "</pre>";
echo "<br><hr>";

echo "<h1>Get Declared Trait</h1>";
echo "<pre>";
print_r(get_declared_traits());
echo "</pre>";