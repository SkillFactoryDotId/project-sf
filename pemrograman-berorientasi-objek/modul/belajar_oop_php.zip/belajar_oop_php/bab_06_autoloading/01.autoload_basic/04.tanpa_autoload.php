<?php
require 'mobil.php';
require 'sepedamotor.php';

$produk01 = new Mobil("Toyota");
echo $produk01->getInfo();

echo "<br>";

$produk02 = new SepedaMotor("Yamaha");
echo $produk02->getInfo();
