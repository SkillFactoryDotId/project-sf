<?php
spl_autoload_register('cekClass');

function cekClass($foo) {
  echo "Nama class yang dicari adalah: ".$foo;
}

//$produk01 = new Mobil();
$produk02 = new SepedaMotor();
