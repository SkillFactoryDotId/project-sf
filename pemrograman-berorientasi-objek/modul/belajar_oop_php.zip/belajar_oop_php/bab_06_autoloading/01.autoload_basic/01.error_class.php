<?php

// $produk01 = new Mobil();
$produk02 = new SepedaMotor();