<?php
spl_autoload_register('cekClass');

function cekClass($foo) {
  echo "require '$foo.php';";
}

$produk01 = new Mobil();
$produk02 = new SepedaMotor();
