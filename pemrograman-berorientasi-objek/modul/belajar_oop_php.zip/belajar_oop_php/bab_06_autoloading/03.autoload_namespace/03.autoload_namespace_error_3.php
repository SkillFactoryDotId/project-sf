<?php

spl_autoload_register(function ($className) {
  echo $className;
});

$produk01 = new Duniailkom\Library\Mobil("Toyota");
echo $produk01->getInfo();
