<?php
spl_autoload_register(function ($className) {
  require str_replace('\\', '/', strtolower("$className.php"));
});

use Duniailkom\Library\Mobil as Mobil;
use Duniailkom\Plugin\SepedaMotor as SepedaMotor;

$produk01 = new Mobil("Toyota");
echo $produk01->getInfo();

echo "<br>";

$produk02 = new SepedaMotor("Yamaha");
echo $produk02->getInfo();
