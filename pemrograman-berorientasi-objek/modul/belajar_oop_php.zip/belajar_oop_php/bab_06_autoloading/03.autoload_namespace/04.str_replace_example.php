<?php
$filePath = 'duniailkom\library\mobil.php';
$hasil = str_replace('\\', '/', $filePath);

echo $hasil;    // duniailkom/library/mobil.php