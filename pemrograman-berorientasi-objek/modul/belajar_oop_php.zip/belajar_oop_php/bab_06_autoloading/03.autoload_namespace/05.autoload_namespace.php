<?php
spl_autoload_register(function ($className) {
  $filePath = strtolower("$className.php");
  echo $filePath ."<br>";
  $filePath = str_replace('\\', '/', $filePath);
  echo $filePath ."<br>";
  require $filePath;
});

$produk01 = new Duniailkom\Library\Mobil("Toyota");
echo $produk01->getInfo();
