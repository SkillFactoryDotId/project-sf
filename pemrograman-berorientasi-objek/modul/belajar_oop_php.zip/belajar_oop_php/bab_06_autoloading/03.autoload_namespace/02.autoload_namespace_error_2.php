<?php

spl_autoload_register(function ($className) {
  $filePath = strtolower("duniailkom/library/$className.php");
  echo $filePath;
  require $filePath;
});

$produk01 = new Duniailkom\Library\Mobil("Toyota");
echo $produk01->getInfo();
