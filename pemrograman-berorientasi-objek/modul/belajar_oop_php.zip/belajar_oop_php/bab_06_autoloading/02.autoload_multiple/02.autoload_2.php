<?php

spl_autoload_register(function ($className){

  $filePath1 = strtolower("library/$className.php");
  if (file_exists($filePath1)) {
    require $filePath1;
  }

  $filePath2 = strtolower("plugin/$className.php");
  if (file_exists($filePath2)) {
    require $filePath2;
  }

});


$produk01 = new Mobil("Toyota");
echo $produk01->getInfo();

echo "<br>";

$produk02 = new SepedaMotor("Yamaha");
echo $produk02->getInfo();

