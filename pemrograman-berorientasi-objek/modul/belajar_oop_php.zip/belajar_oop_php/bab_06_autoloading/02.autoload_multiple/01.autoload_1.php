<?php
spl_autoload_register('importLibraryClass');
spl_autoload_register('importPluginClass');

function importLibraryClass($className){
  $filePath = strtolower("library/$className.php");

  if (file_exists($filePath)) {
    require $filePath;
  }
}

function importPluginClass($className){
  $filePath = strtolower("plugin/$className.php");

  if (file_exists($filePath)) {
    require $filePath;
  }
}

$produk01 = new Mobil("Toyota");
echo $produk01->getInfo();

echo "<br>";

$produk02 = new SepedaMotor("Yamaha");
echo $produk02->getInfo();
