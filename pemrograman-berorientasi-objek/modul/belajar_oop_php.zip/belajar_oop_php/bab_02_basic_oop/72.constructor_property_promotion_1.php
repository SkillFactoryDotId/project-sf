<?php
class Produk {
  public function __construct(public $jenis, public $merek, public $stok) { 
  }
}

$produk01 = new Produk("Televisi","Samsung",20);
$produk02 = new Produk("Mesin cuci","LG",10);

print_r ($produk01);
echo "<br>";
print_r ($produk02);