<?php
class Produk {
  final public $hehe = 12;
}

// Fatal error: Cannot declare property Produk::$hehe final, 
// the final modifier is allowed only for methods and classes
