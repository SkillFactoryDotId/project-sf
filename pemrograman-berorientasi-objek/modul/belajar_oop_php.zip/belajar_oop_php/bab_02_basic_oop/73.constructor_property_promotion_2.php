<?php
class Produk {
  public function __construct(
    public $jenis, 
    private $merek = "Maspion", 
    protected $stok = 10) { 

    echo "Produk $this->jenis dibuat <br>";
  }
}

$produk01 = new Produk("Televisi","Samsung",20);
$produk02 = new Produk("Mesin cuci");

print_r ($produk01);
echo "<br>";
print_r ($produk02);