<?php
class Produk {
  private const KURSUSD = 15000;
}

echo Produk::KURSUSD;         
// Fatal error: Uncaught Error: Cannot access private const Produk::KURSUSD