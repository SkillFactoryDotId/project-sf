<?php
class Produk {
  
}

$televisi = new Produk();