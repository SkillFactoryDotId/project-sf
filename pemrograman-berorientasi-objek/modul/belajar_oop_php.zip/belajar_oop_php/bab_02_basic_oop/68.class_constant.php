<?php
class Produk {
  public const KURSUSD = 15000;
}

echo Produk::KURSUSD;         // 15000
