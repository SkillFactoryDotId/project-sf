<?php
final class Produk {
  public function hello(){
    return "Ini dari Produk";
  }
}

class Televisi extends Produk {
 }

// Fatal error: Class Televisi may not inherit from final class (Produk) 
