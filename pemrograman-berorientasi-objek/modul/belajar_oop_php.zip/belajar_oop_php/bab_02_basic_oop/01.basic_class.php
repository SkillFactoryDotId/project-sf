<?php
class Produk {
  
}

$televisi = new Produk();
$buku = new Produk();
$smartphone = new Produk();