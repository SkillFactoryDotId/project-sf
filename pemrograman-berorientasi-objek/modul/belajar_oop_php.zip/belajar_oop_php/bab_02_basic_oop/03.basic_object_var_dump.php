<?php
class Produk {
  
}

$televisi = new Produk();

var_dump($televisi);    //  object(Produk)#1 (0) { }