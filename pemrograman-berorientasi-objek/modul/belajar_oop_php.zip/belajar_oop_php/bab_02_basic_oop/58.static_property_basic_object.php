<?php
class Produk {
  public static $totalProduk = 100;
}

$produk01 = new Produk();
echo $produk01->totalProduk;
