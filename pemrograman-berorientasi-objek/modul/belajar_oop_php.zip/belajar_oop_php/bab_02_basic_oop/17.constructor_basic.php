<?php
class Produk {

  public function __construct(){
    echo "Constructor dijalankan... <br>";
  }
  
}

$produk01 = new Produk();
$produk02 = new Produk();
