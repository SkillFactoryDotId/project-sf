<?php
class Produk {
  public static $totalProduk = 100;
}

echo Produk::$totalProduk;  // 100
